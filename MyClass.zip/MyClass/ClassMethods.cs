﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyClass
{
    class ClassMethods
    {
        public static void PrintMarks(Student student)
        {
            Console.WriteLine(new string('-', 30));
            Console.WriteLine("Marks:");
            foreach (KeyValuePair<Subject, List<int>> item in student.Marks)
            {
                Console.WriteLine(item.Key.ToString() + " - " + string.Join(", ", item.Value));
            }
            Console.WriteLine(new string('-', 30));
        }

        public static void PrintName(Student student)
        {
            Console.WriteLine(new string('-', 30));
            Console.WriteLine($"Name: {student.Name}");
        }

        public static void PrintLastName(Student student)
        {
            Console.WriteLine(new string('-', 30));
            Console.WriteLine($"Last Name: {student.LastName}");
        }

        public static void PrintAge(Student student)
        {
            Console.WriteLine(new string('-', 30));
            Console.WriteLine($"Age: {student.Age}");
        }

        public static void PrintPhoneNumber(Student student)
        {
            Console.WriteLine(new string('-', 30));
            Console.WriteLine($"Phone Number: {student.PhoneNumber}");
        }

        public static void PrintCity(Student student)
        {
            Console.WriteLine(new string('-', 30));
            Console.WriteLine($"City: {student.City}");
        }

        public static void PrintNubmerInClass(Student student)
        {
            Console.WriteLine(new string('-', 30));
            Console.WriteLine($"Number in class: {student.Number}");
        }

        public static void PrintFavouriteSubject(Student student)
        {
            Console.WriteLine(new string('-', 30));
            Console.WriteLine($"Favourite Subject: {student.FavouriteSubject}");
        }

        public static void StudentInfo(Student student)
        {
            PrintName(student);
            PrintLastName(student);
            PrintAge(student);
            PrintPhoneNumber(student);
            PrintCity(student);
            PrintNubmerInClass(student);
            PrintFavouriteSubject(student);
            PrintMarks(student);
        }

    }
}
