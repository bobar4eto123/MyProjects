﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyClass
{
    public class Human
    {
        public string Name { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; }
        public string PhoneNumber { get; set; }
        public string City { get; set; }

        public Human()
        {
            this.Name = "";
            this.LastName = "";
            this.Age = 0;
            this.PhoneNumber = "";
            this.City = "";
        }

        public Human(string name, string lastName, int age, string phoneNumber, string city)
        {
            this.Name = name;
            this.LastName = lastName;
            this.Age = age;
            this.PhoneNumber = phoneNumber;
            this.City = city;
        }

        public Human(string name, string lastName, int age, string city)
        {
            this.Name = name;
            this.LastName = lastName;
            this.Age = age;
            this.PhoneNumber = null;
            this.City = city;
        }

        public Human(string name, string lastName, int age)
        {
            this.Name = name;
            this.LastName = lastName;
            this.Age = age;
        }


    }
}
