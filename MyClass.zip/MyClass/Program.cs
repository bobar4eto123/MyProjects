﻿using System;
using System.Reflection;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using System.Threading.Tasks;
using System.IO;

namespace MyClass
{
    class Program
    {

        static string jsonFilesPath = Directory.GetParent(Environment.CurrentDirectory).Parent.Parent.FullName;

        static void Main(string[] args)
        {
            ClassMethods commandInterpreter = new ClassMethods();
            int studentsInClass = 26;

            Teacher[] teachers = new Teacher[18];
            //GenerateJson(teachers, "teachers.json");
            DeserializeTo<Teacher[]>("teachers.json", ref teachers);

            Subject[] subjects = new Subject[16];           
            DeserializeTo<Subject[]>("subjects.json", ref subjects);
            //GenerateJson(subjects, "subjects.json");

            List<Marks> marks = new List<Marks>(studentsInClass);
            SetRandomMarks(ref marks, subjects);
            GenerateJson(marks, "marks.json");

            Student[] students = new Student[studentsInClass];       
            DeserializeTo<Student[]>("students.json", ref students);
            for (int i = 0; i < students.Length; i++) students[i].Marks = marks[i];
            GenerateJson(students, "students.json");

            //----------------------------FUNCTION-------------------------------------//

            //Subject ToSubject(string subject)
            //{
            //    switch (subject)
            //    {
            //        case "English":
            //            return english;
            //        case "Bulgarian":
            //            return bulgarian;
            //        case "Maths":
            //            return maths;
            //        case "Philosophy":
            //            return philosophy;
            //        case "Informatics":
            //            return informatics1;
            //        case "Informatics2":
            //            return informatics2;
            //        case "Information and Communications Technologies":
            //            return ict;
            //        case "Art":
            //            return art;
            //        case "Music":
            //            return music;
            //        case "History":
            //            return history;
            //        case "Physical Education":
            //            return pe;
            //        default:
            //            return english;
            //    }
            //}

            //------------------------------------------------------------------------//

            //using (StreamReader reader = new StreamReader("database.txt"))
            //{
            //    for (int i = 0; i < marks.Length; i++)
            //    {
            //        Marks currentStudentMarks = new Marks();
            //        string row = reader.ReadLine();
            //        string[] kvpairs = row.Split('~');

            //        for (int k = 0; k < kvpairs.Length; k++)
            //        {
            //            string currentPair = kvpairs[k];
            //            Subject currentSubject = ToSubject(currentPair.Split(' ')[0]);
            //            List<int> currentMarks = currentPair.Split(' ')[1].Split(',').Select(int.Parse).ToList();
            //            currentStudentMarks.Add(currentSubject, currentMarks);
            //        }

            //        marks[i] = currentStudentMarks;
            //    }
            //}

            while (true)
            {
                string command = Console.ReadLine();
                string[] name = Console.ReadLine().Split(' ');
                int index = 0;

                for (int i = 0; i < students.Length; i++)
                {
                    if (name[0] == students[i].Name && name[1] == students[i].LastName)
                    {
                        index = i;
                    }
                }

                var type = typeof(ClassMethods);
                type.GetMethod(command).Invoke(commandInterpreter, new object[] { students[index] });
            }



            //using (StreamWriter writer = new StreamWriter("database.txt"))
            //{
            //    for (int i = 0; i < marks.Count; i++)
            //    {
            //        foreach (var pair in marks[i])
            //        {
            //            writer.Write(pair.Key.ToString() + " " + string.Join(",", pair.Value));
            //            writer.Write("~");
            //        }
            //        writer.WriteLine();
            //    }
            //}

        }

        static void GenerateJson(object objToSerialize, string fileName)
        {
            using (StreamWriter toshko = new StreamWriter(Path.Combine(jsonFilesPath, fileName), false))
            {
                string json = JsonConvert.SerializeObject(objToSerialize, Formatting.Indented);
                toshko.Write(json);
            }
        }

        static void DeserializeTo<T>(string fileName, ref T deserializeTo)
        {
            JsonSerializerSettings settings = new JsonSerializerSettings();
            settings.ContractResolver = new EmptyDictionaryObjectResolver();

            using (StreamReader toshko = new StreamReader(Path.Combine(jsonFilesPath, fileName)))
            {
                string jsonText = toshko.ReadToEnd();
                deserializeTo = JsonConvert.DeserializeObject<T>(jsonText, settings);
            }
        }

        static void SetRandomMarks(ref List<Marks> marksOfAllStudents, Subject[] subjects)
        {
            for (int i = 0; i < marksOfAllStudents.Capacity; i++)
            {
                Marks randomMarks = new Marks();
                Random generator = new Random(DateTime.Now.Millisecond);
                for (int k = 0; k < subjects.Length; k++)
                {
                    List<int> randomSubjectMarks = new List<int>(4);
                    for (int j = 0; j < 4; j++) randomSubjectMarks.Add(generator.Next(2, 7));

                    randomMarks.Add(subjects[k], randomSubjectMarks);
                }
                marksOfAllStudents.Add(randomMarks);
            }
        }
    }
}
