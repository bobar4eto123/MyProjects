﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyClass
{
    class Student : Human
    {
        public Dictionary<Subject, List<int>> Marks { get; set; }

        public int Number { get; set; }

        public Subject FavouriteSubject { get; set; }

        public Student()
        {
            this.Marks = new Marks();
            this.FavouriteSubject = new Subject();
        }

        public Student(string name, string lastName, int age, Dictionary<Subject, List<int>> marks, int number, Subject favouriteSubject) : base(name, lastName, age)
        {
            this.Marks = marks;
            this.Number = number;
            this.FavouriteSubject = favouriteSubject;
        }

        public Student(string name, string lastName, int age, string phoneNumber, string city, Dictionary<Subject, List<int>> marks, int number, Subject favouriteSubject) : base(name, lastName, age, phoneNumber, city)
        {
            this.Marks = marks;
            this.Number = number;
            this.FavouriteSubject = favouriteSubject;
        }

    }
}
