﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyClass
{
    class Subject
    {
        public string Name { get; set; }

        public Teacher Teacher { get; set; }

        public Teacher Teacher2 { get; set; }

        public Subject()
        {
            this.Name = string.Empty;
            this.Teacher = new Teacher();

        }

        public Subject(string name, Teacher teacher)
        {
            this.Name = name;
            this.Teacher = teacher;

        }

        //public Subject(string name, Teacher teacher, Teacher teacher2)
        //{
        //    this.Name = name;
        //    this.Teacher = teacher;
        //    this.Teacher2 = teacher2;
        //}

        public override string ToString()
        {
            return this.Name;
        }
    }
}
