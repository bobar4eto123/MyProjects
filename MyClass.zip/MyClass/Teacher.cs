﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyClass
{
    class Teacher : Human
    {
        public Teacher() : base()
        {

        }

        public Teacher(string name, string lastName, int age, string phoneNumber, string city) : base(name, lastName, age, phoneNumber, city)
        {

        }

        public Teacher(string name, string lastName, int age, string city) : base(name, lastName, age, city)
        {

        }

        public Teacher(string name, string lastName, int age) : base(name, lastName, age)
        {
            this.City = "Ruse";
        }
    }
}
